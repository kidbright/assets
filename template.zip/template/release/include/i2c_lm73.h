#ifndef __I2C_LM73_H__
#define __I2C_LM73_H__

#ifdef __cplusplus
extern "C" {
#endif

double i2c_lm73_get(void);
int i2c_lm73_error(void);
int i2c_lm73_initialized(void);
void i2c_lm73_proc(void);
void i2c_lm73_init(void);

#ifdef __cplusplus
}
#endif

#endif
