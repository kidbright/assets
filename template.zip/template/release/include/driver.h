#ifndef __DRIVER_H__
#define __DRIVER_H__

#define DRIVER_DATA_STRING_SIZE				32
// 100 = 2 decimal digits
#define DRIVER_DATA_PREC_COEF				100

#define IS_FLAG_SET(x, b)					(x & b)
#define FLAG_SET(x, b)						(x |= b)
#define FLAG_CLR(x, b)						(x &= (~b))

#define DRIVER_TICK_MS						50
#define DRIVER_CNT_MS(x)					(x / DRIVER_TICK_MS)

#define LDR_POLLING_MS						1000
#define LM73_POLLING_MS						1000
#define DS3231_POLLING_MS					250
#define SENSOR_HUB_POLLING_MS				250
#define SWLED_POLLING_MS					50
#define RELAY_POLLING_MS					250

#ifdef __cplusplus
extern "C" {
#endif

//typedef void (*t_void_func)(void);

#ifdef __cplusplus
}
#endif

#endif
