#ifndef __I2C_DS3231_H__
#define __I2C_DS3231_H__

#ifdef __cplusplus
extern "C" {
#endif

char *i2c_ds3231_get_datetime(void);
char *i2c_ds3231_get_date(void);
char *i2c_ds3231_get_time(void);
int i2c_ds3231_get(int index);
void i2c_ds3231_write(char *str);
void i2c_ds3231_cal(int val);
void i2c_ds3231_cal_coarse(int val);

#ifdef __cplusplus
}
#endif

#endif
