#ifndef __BUTTON12_H__
#define __BUTTON12_H__

#ifdef __cplusplus
extern "C" {
#endif

void button12_proc(void);
int switch1_get(void);
int switch2_get(void);
void wait_sw1_pressed(void);
void wait_sw1_released(void);
void wait_sw2_pressed(void);
void wait_sw2_released(void);
int is_sw1_pressed(void);
int is_sw1_released(void);
int is_sw2_pressed(void);
int is_sw2_released(void);
void button12_init(void);

#ifdef __cplusplus
}
#endif

#endif
