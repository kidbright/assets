#ifndef __GPIO0_H__
#define __GPIO0_H__

#include "driver.h"

#ifdef __cplusplus
extern "C" {
#endif

void gpio0_write(bool val);
void gpio0_toggle(void);
drv_data_t *gpio0_read(void);
void gpio0_init(void);

#ifdef __cplusplus
}
#endif

#endif
