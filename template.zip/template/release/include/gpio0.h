#ifndef __GPIO0_H__
#define __GPIO0_H__

#ifdef __cplusplus
extern "C" {
#endif

void gpio0_write(int val);
void gpio0_toggle(void);
int gpio0_read(void);
void gpio0_init(void);

#ifdef __cplusplus
}
#endif

#endif
