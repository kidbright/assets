#ifndef __I2C_SWLED_H__
#define __I2C_SWLED_H__

#ifdef __cplusplus
extern "C" {
#endif

int swled_sw1_get(void);
int swled_sw2_get(void);
int swled_sw3_get(void);
int swled_sw4_get(void);
void swled_led1_write(bool val);
void swled_led2_write(bool val);
void swled_led3_write(bool val);
void swled_led4_write(bool val);
void swled_led1_toggle(void);
void swled_led2_toggle(void);
void swled_led3_toggle(void);
void swled_led4_toggle(void);
int i2c_swled_error(void);
int i2c_swled_initialized(void);
void i2c_swled_proc(void);
void i2c_swled_init(void);

#ifdef __cplusplus
}
#endif

#endif
