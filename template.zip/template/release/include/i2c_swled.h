#ifndef __I2C_SWLED_H__
#define __I2C_SWLED_H__

#include "driver.h"

#ifdef __cplusplus
extern "C" {
#endif

drv_data_t *swled_sw1_get(void);
drv_data_t *swled_sw2_get(void);
drv_data_t *swled_sw3_get(void);
drv_data_t *swled_sw4_get(void);

#ifdef __cplusplus
}
#endif

#endif
