#ifndef __I2C_SENSOR_HUB_H__
#define __I2C_SENSOR_HUB_H__

#ifdef __cplusplus
extern "C" {
#endif

int sensor_hub_w1_get(void);
int sensor_hub_w2_get(void);
int sensor_hub_d1_get(void);
int sensor_hub_d2_get(void);
int sensor_hub_d3_get(void);
int sensor_hub_d4_get(void);

void sensor_hub_u1_write(bool val);
void sensor_hub_u1_toggle(void);
int sensor_hub_u1_read(void);
void sensor_hub_u2_write(bool val);
void sensor_hub_u2_toggle(void);
int sensor_hub_u2_read(void);

int i2c_sensor_hub_error(void);
int i2c_sensor_hub_initialized(void);
void i2c_sensor_hub_proc(void);
void i2c_sensor_hub_init(void);

#ifdef __cplusplus
}
#endif

#endif
