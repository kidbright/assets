#ifndef __I2C_SENSOR_HUB_H__
#define __I2C_SENSOR_HUB_H__

#include "driver.h"

#ifdef __cplusplus
extern "C" {
#endif

drv_data_t *sensor_hub_w1_get(void);
drv_data_t *sensor_hub_w2_get(void);
drv_data_t *sensor_hub_d1_get(void);
drv_data_t *sensor_hub_d2_get(void);
drv_data_t *sensor_hub_d3_get(void);
drv_data_t *sensor_hub_d4_get(void);

void sensor_hub_u1_write(bool val);
void sensor_hub_u1_toggle(void);
drv_data_t *sensor_hub_u1_read(void);
void sensor_hub_u2_write(bool val);
void sensor_hub_u2_toggle(void);
drv_data_t *sensor_hub_u2_read(void);

#ifdef __cplusplus
}
#endif

#endif
