#ifndef __LDR_H__
#define __LDR_H__

#include "driver.h"

#ifdef __cplusplus
extern "C" {
#endif

drv_data_t *ldr_get(void);

#ifdef __cplusplus
}
#endif

#endif
