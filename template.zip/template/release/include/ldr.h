#ifndef __LDR_H__
#define __LDR_H__

#ifdef __cplusplus
extern "C" {
#endif

int ldr_get(void);
void ldr_proc(void);
void ldr_init(void);

#ifdef __cplusplus
}
#endif

#endif
