#ifndef __SOUND_H__
#define __SOUND_H__

#ifdef __cplusplus
extern "C" {
#endif

void sound_on(uint32_t freq, uint8_t duty_in_percent);
void sound_off(void);
void sound_note(uint8_t note);
void sound_rest(uint8_t duration);
uint32_t sound_get_bpm(void);
void sound_set_bpm(uint32_t val);

#ifdef __cplusplus
}
#endif

#endif
