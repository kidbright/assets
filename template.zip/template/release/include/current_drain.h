#ifndef __GPIO0_H__
#define __GPIO0_H__

#include "driver.h"

#ifdef __cplusplus
extern "C" {
#endif

void current_drain_write(bool val);
void current_drain_init(void);

#ifdef __cplusplus
}
#endif

#endif
