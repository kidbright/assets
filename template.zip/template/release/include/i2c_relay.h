#ifndef __I2C_RELAY_H__
#define __I2C_RELAY_H__

#ifdef __cplusplus
extern "C" {
#endif

int relay1_get(void);
int relay2_get(void);
int relay3_get(void);
int relay4_get(void);
void relay_write(uint8_t bit, bool val);
void relay_toggle(uint8_t bit);

#ifdef __cplusplus
}
#endif

#endif
