#ifndef __I2C_HT16K33_H__
#define __I2C_HT16K33_H__

#ifdef __cplusplus
extern "C" {
#endif

void i2c_ht16k33_show(uint8_t *buf);
void i2c_ht16k33_scroll(char *buf, bool scroll_flag);
void i2c_ht16k33_scroll_number(double val, bool scroll_flag, bool fixed_2digits_flag);
int i2c_ht16k33_error(void);
int i2c_ht16k33_initialized(void);
int i2c_ht16k33_busy(void);
int i2c_ht16k33_idle(void);
void wait_led_matrix_ready(void);
void i2c_ht16k33_proc(void);
void i2c_ht16k33_init(void);

#ifdef __cplusplus
}
#endif

#endif
