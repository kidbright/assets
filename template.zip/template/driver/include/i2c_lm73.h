#ifndef __I2C_LM73_H__
#define __I2C_LM73_H__

#include "driver.h"

#ifdef __cplusplus
extern "C" {
#endif

drv_data_t *i2c_lm73_get(void);

#ifdef __cplusplus
}
#endif

#endif
