#ifndef __BUTTON12_H__
#define __BUTTON12_H__

#include "driver.h"

#ifdef __cplusplus
extern "C" {
#endif

drv_data_t *switch1_get(void);
drv_data_t *switch2_get(void);

#ifdef __cplusplus
}
#endif

#endif
