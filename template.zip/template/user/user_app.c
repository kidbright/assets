#include "esp_common.h"
#include "user_config.h"

void user_app(void) {
  // setup
  while(1) {
    if (i2c_ht16k33_idle()) { i2c_ht16k33_scroll(i2c_ds3231_get()->string); }
    vTaskDelay(500 / portTICK_RATE_MS);
  }
  
  // create tasks
}