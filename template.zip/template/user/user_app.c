#include "esp_common.h"
#include "user_config.h"

void user_app(void) {
  // setup
  i2c_ht16k33_show("\x80\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0\x0");
  
  // create tasks
}