#include "esp_common.h"
#include "user_config.h"

void user_app(void) {
  // setup
  while(1) {
    gpio0_toggle();
    vTaskDelay(500 / portTICK_RATE_MS);
  }
  
  // create tasks
}