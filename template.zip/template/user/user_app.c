#include "esp_common.h"
#include "user_config.h"

LOCAL void vTask1(void *pvParameters) {
  while(1) {
    i2c_ht16k33_scroll(ldr_get()->string);
    vTaskDelay(5000 / portTICK_RATE_MS);
  }
  // kill itself
  vTaskDelete(NULL);
}

LOCAL void vTask2(void *pvParameters) {
  while(1) {
    if (ldr_get()->value >= 30) {
      sound_note(12);
      sound_rest(4);
      sound_off();
    } else {
      sound_note(0);
      sound_rest(4);
      sound_off();
    }
    vTaskDelay(500 / portTICK_RATE_MS);
  }
  // kill itself
  vTaskDelete(NULL);
}

void user_app(void) {
  // setup
  
  // create tasks
  xTaskCreate(vTask1, "vTask1", USER_STACK_SIZE_MIN, NULL, USER_TASK_PRIORITY, NULL);
  xTaskCreate(vTask2, "vTask2", USER_STACK_SIZE_MIN, NULL, USER_TASK_PRIORITY, NULL);
}