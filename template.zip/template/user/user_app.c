#include "esp_common.h"
#include "user_config.h"

void user_app(void) {
  // setup
  while(1) {
    i2c_ht16k33_scroll(i2c_ds3231_get()->string);
    vTaskDelay(10000 / portTICK_RATE_MS);
  }
  
  // create tasks
}