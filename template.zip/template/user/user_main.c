#include "esp_common.h"
#include "user_config.h"
#include "gpio.h"
#include "uart.h"
#include "wiring.h"

/*
VERBOSE=1 make clean;VERBOSE=1 make BOOT=new APP=1 SPI_SPEED=40 SPI_MODE=QIO SPI_SIZE_MAP=7
*/

#define CURRENT_DRAIN_PIN		GPIO_Pin_12


LOCAL void vCurrentDrainTask(void *pvParameters) {
	while (1) {
		GPIO_OUTPUT(CURRENT_DRAIN_PIN, 1);
		vTaskDelay(1000 / portTICK_RATE_MS);
		GPIO_OUTPUT(CURRENT_DRAIN_PIN, 0);
		vTaskDelay(1000 / portTICK_RATE_MS);
	}
}

LOCAL void vUdpServiceTask(void *pvParameters) {
	struct ip_info ip_config;

	// wait assigned ip address
	wifi_get_ip_info(STATION_IF, &ip_config);
	while(ip_config.ip.addr == 0){
		vTaskDelay(1000 / portTICK_RATE_MS);
		wifi_get_ip_info(STATION_IF, &ip_config);
	}

	// init udp service
	udp_service_init();

	while (1) {
		vTaskDelay(1000 / portTICK_RATE_MS);
	}
}

LOCAL void vUserStartupTask(void *pvParameters) {
	// wait i2c driver ready
	while (!i2c_state_ready()) {
		vTaskDelay(100 / portTICK_RATE_MS);
	}

	// real user app
	user_app();

	// kill itself
	vTaskDelete(NULL);
}

void user_init(void) {
	// uart init
	uart_init_new();
	UART_SetBaudrate(UART0, BIT_RATE_115200);

	// http://patorjk.com/software/taag/#p=display&f=Graceful&t=Kid-Bright
	os_printf("\n\n");
	os_printf(" __ _  __  ____      ____  ____  __  ___  _  _  ____ \n");
	os_printf("(  / )(  )(    \\ ___(  _ \\(  _ \\(  )/ __)/ )( \\(_  _)\n");
	os_printf(" )  (  )(  ) D ((___)) _ ( )   / )(( (_ \\) __ (  )(  \n");
	os_printf("(__\\_)(__)(____/    (____/(__\\_)(__)\\___/\\_)(_/ (__) \n");
	os_printf("SDK version:%s\n", system_get_sdk_version());

	// setup wifi
	wifi_set_opmode(STATION_MODE);

	PIN_FUNC_SELECT(PERIPHS_IO_MUX_MTDI_U, FUNC_GPIO12); // http://www.esp8266.com/viewtopic.php?f=13&t=5947#sthash.YGYCNJ3E.dpuf
	GPIO_AS_OUTPUT(CURRENT_DRAIN_PIN);
	GPIO_OUTPUT(CURRENT_DRAIN_PIN, 0);

	// create tasks
	xTaskCreate(vCurrentDrainTask, "Current Drain Task", USER_STACK_SIZE_MIN, NULL, USER_TASK_PRIORITY, NULL);
	xTaskCreate(vUdpServiceTask, "UdpService Task", USER_STACK_SIZE_MIN, NULL, USER_TASK_PRIORITY, NULL);
	device_create_task();
	xTaskCreate(vUserStartupTask, "User Startup Task", USER_STACK_SIZE_MIN, NULL, USER_TASK_PRIORITY, NULL);
}
