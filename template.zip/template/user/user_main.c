#include "esp_common.h"
#include "user_config.h"
#include "gpio.h"
#include "uart.h"
#include "wiring.h"

/*
VERBOSE=1 make clean;VERBOSE=1 make BOOT=new APP=1 SPI_SPEED=40 SPI_MODE=QIO SPI_SIZE_MAP=7
*/

#define	STATUS_LED									2
#define NETWORK_TIMER_CB_IN_MS			500
#define NETWORK_CON_CHK_DLY_CNT			4
#define NETWORK_DISCON_CHK_DLY_CNT	10

uint8 led_status;
bool network_connected;

void set_network_status(uint8 stat) {
	if (stat == 0) {
		led_status = 1;
		network_connected = false;
	}
	else {
		led_status = 0;
		network_connected = true;
	}
	GPIO_OUTPUT_SET(GPIO_ID_PIN(STATUS_LED), led_status);
}

LOCAL void vNetworkServiceTask(void *pvParameters) {
	struct ip_info ip_config;
	uint8 network_timer_cnt = 4;

	while (1) {
		// check if counter reached to check network status
		if (network_timer_cnt > 0) {
			network_timer_cnt--;
			if (!network_connected) {
				// status led toggle
				led_status = (~led_status) & 0x01;
				GPIO_OUTPUT_SET(GPIO_ID_PIN(STATUS_LED), led_status);
			}
		}
		else {
			wifi_get_ip_info(STATION_IF, &ip_config);
			if (wifi_station_get_connect_status() == STATION_GOT_IP && ip_config.ip.addr != 0) {
				if (!network_connected) {
					set_network_status(1);
				}

				// use wait disconnect delay count (5 sec)
				network_timer_cnt = NETWORK_DISCON_CHK_DLY_CNT;
			} else {
				set_network_status(0);

				// use wait connect delay count (2 sec)
				network_timer_cnt = NETWORK_CON_CHK_DLY_CNT;
			}
		}

		vTaskDelay(NETWORK_TIMER_CB_IN_MS / portTICK_RATE_MS);
	}
}

LOCAL void vUserStartupTask(void *pvParameters) {
	// wait i2c driver ready
	while (!i2c_state_ready()) {
		vTaskDelay(100 / portTICK_RATE_MS);
	}

	// real user app
	user_app();

	// kill itself
	vTaskDelete(NULL);
}

void user_init(void) {
	// uart init
	uart_init_new();
	UART_SetBaudrate(UART0, BIT_RATE_115200);

	// wifi status = gpio2 (reconfigure GPIO2 for used as wifi status)
	PIN_FUNC_SELECT(PERIPHS_IO_MUX_GPIO2_U, FUNC_GPIO2);
	set_network_status(0);

	// http://patorjk.com/software/taag/#p=display&f=Graceful&t=Kid-Bright
	os_printf("\n\n");
	os_printf(" __ _  __  ____      ____  ____  __  ___  _  _  ____ \n");
	os_printf("(  / )(  )(    \\ ___(  _ \\(  _ \\(  )/ __)/ )( \\(_  _)\n");
	os_printf(" )  (  )(  ) D ((___)) _ ( )   / )(( (_ \\) __ (  )(  \n");
	os_printf("(__\\_)(__)(____/    (____/(__\\_)(__)\\___/\\_)(_/ (__) \n");
	os_printf("SDK version:%s\n", system_get_sdk_version());

	// setup wifi
	wifi_set_opmode(STATION_MODE);

	// init udp service
	udp_service_init();

	// create tasks
	xTaskCreate(vNetworkServiceTask, "NetworkService Task", USER_STACK_SIZE_MIN, NULL, USER_TASK_PRIORITY, NULL);
	device_create_task();
	xTaskCreate(vUserStartupTask, "User Startup Task", USER_STACK_SIZE_MIN, NULL, USER_TASK_PRIORITY, NULL);
}
