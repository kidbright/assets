#include "esp_common.h"
#include "lwip/udp.h"
#include "lwip/mem.h"
#include "i2c.h"

#define SSID_STR_LEN									6
#define UDP_SERVICE_PORT							8266
#define SECTOR_SIZE										0x1000
#define BOOT_CONFIG_SECTOR						1
#define MAX_ROMS											4
#define DS3231_ADDR										0x68

typedef struct {
	uint8 magic;           ///< Our magic, identifies rBoot configuration - should be BOOT_CONFIG_MAGIC
	uint8 version;         ///< Version of configuration structure - should be BOOT_CONFIG_VERSION
	uint8 mode;            ///< Boot loader mode (MODE_STANDARD | MODE_GPIO_ROM)
	uint8 current_rom;     ///< Currently selected ROM (will be used for next standard boot)
	uint8 gpio_rom;        ///< ROM to use for GPIO boot (hardware switch) with mode set to MODE_GPIO_ROM
	uint8 count;           ///< Quantity of ROMs available to boot
	uint8 unused[2];       ///< Padding (not used)
	uint32 roms[MAX_ROMS]; ///< Flash addresses of each ROM
#ifdef BOOT_CONFIG_CHKSUM
	uint8 chksum;          ///< Checksum of this configuration structure (if BOOT_CONFIG_CHKSUM defined)
#endif
} rboot_config;

LOCAL struct udp_pcb *ptel_pcb;
LOCAL os_timer_t restart_timer;
char SSID[SSID_STR_LEN + 1];

const char *udp_rom_cmd = "rom";
const char *udp_switch_cmd = "switch";
const char *udp_rtcset_cmd = "rtcset";
const char rom_msg[] = "Currently running rom 0\r\n";
const char switch_msg[] = "rebooting to rom 1...\r\n";
const char ok_msg[] = "ok\r\n";
const char err_msg[] = "error\r\n";

// reboot
void ICACHE_FLASH_ATTR reboot(void) {
	os_timer_disarm(&restart_timer);
	os_timer_setfn(&restart_timer, (os_timer_func_t *)system_restart, NULL);
	os_timer_arm(&restart_timer, 500, 0);
}

// get the rboot config
rboot_config ICACHE_FLASH_ATTR rboot_get_config(void) {
	rboot_config conf;

	spi_flash_read(BOOT_CONFIG_SECTOR * SECTOR_SIZE, (uint32*)&conf, sizeof(rboot_config));
	return conf;
}

// write the rboot config
// preserves the contents of the rest of the sector,
// so the rest of the sector can be used to store user data
// updates checksum automatically (if enabled)
bool ICACHE_FLASH_ATTR rboot_set_config(rboot_config *conf) {
	uint8 *buffer;

	buffer = (uint8*)mem_malloc(SECTOR_SIZE);
	if (buffer == NULL) {
		return NULL;
	}

	if (!buffer) {
		//os_printf("No ram!\r\n");
		return FALSE;
	}

#ifdef BOOT_CONFIG_CHKSUM
	conf->chksum = calc_chksum((uint8*)conf, (uint8*)&conf->chksum);
#endif

	spi_flash_read(BOOT_CONFIG_SECTOR * SECTOR_SIZE, (uint32*)((void*)buffer), SECTOR_SIZE);
	MEMCPY(buffer, conf, sizeof(rboot_config));
	spi_flash_erase_sector(BOOT_CONFIG_SECTOR);
	spi_flash_write(BOOT_CONFIG_SECTOR * SECTOR_SIZE, (uint32*)((void*)buffer), SECTOR_SIZE);

	mem_free(buffer);

	return TRUE;
}

// set current boot rom
bool ICACHE_FLASH_ATTR rboot_set_current_rom(uint8 rom) {
	rboot_config conf;

	conf = rboot_get_config();
	if (rom >= conf.count) {
		return FALSE;
	}
	conf.current_rom = rom;
	return rboot_set_config(&conf);
}

void ICACHE_FLASH_ATTR udp_service_reply(const char *str, uint8 size, struct udp_pcb *pcb, struct ip_addr *addr) {
	struct pbuf *r;

	r = pbuf_alloc(PBUF_TRANSPORT, size, PBUF_RAM);
	MEMCPY(r->payload, str, size);
	r->len = size;
	r->tot_len = size;
	udp_sendto(pcb, r, addr, UDP_SERVICE_PORT);
	pbuf_free(r);
}

uint8 str2dec(char *str) {
	return ((str[0] - 0x30) * 10) + (str[1] - 0x30);
}

uint8 str2bcd(char *str) {
	return (((str[0] - 0x30) << 4) & 0xf0) | ((str[1] - 0x30) & 0x0f);
}

bool rtcset_ds3231(char *str) {
	uint8 ds3231_buffer[8];
	uint8 i;
	char msg[64] = {0};
	bool err_flag = false;

	// second, minute, hour
	for (i=0; i<3; i++) {
		ds3231_buffer[2 - i] = str2bcd(&str[8 + i*2]);
	}
	// day of week, ds3231 = one based
	ds3231_buffer[3] = str2dec(&str[6]) + 1;
	// day, month, year
	for (i=0; i<3; i++) {
		ds3231_buffer[6 - i] = str2bcd(&str[i*2]);
	}

	// write to rtc
	//os_printf("detecting rtc chip...");
	i2c_master_start();
	i2c_master_writeByte(I2C_ADDR_WRITE(DS3231_ADDR));
	if (!i2c_master_checkAck()) {
		//os_printf(", failed!\r\n");
		err_flag = true;
	}
	else {
		//os_printf(", ok.\r\n");
		// set address pointer to 0
		i2c_master_writeByte(0);
		if (!i2c_master_checkAck()) {
				err_flag = true;
		}
		else {
			// write rtc
			for (i=0; i<7; i++) {
				i2c_master_writeByte(ds3231_buffer[i]);
				if (!i2c_master_checkAck()) {
						err_flag = true;
				}
			}
		}
	}
	i2c_master_stop();

	return (!err_flag);
}

void ICACHE_FLASH_ATTR udp_service_recv(void *arg, struct udp_pcb *pcb, struct pbuf *p, struct ip_addr *addr, uint16 port) {
	char *str, *udp_cmd;
	uint8 i, length;
	bool ok_flag;

	// test: nc -u 192.168.1.208 8266
  if (p != NULL) {
		str = (char *)p->payload;
		length = p->len;

		// tailing trim  \r or \n
		i = length - 1;
		while ((str[i] == '\r') || (str[i] == '\n')) {
			str[i] = '\x0';
			i--;
		}
		length = strlen(str);

		// check ssid: first
		if ((strncmp(str, SSID, SSID_STR_LEN) == 0) & (length >= (SSID_STR_LEN + 1))) {
			// extract udp command
			udp_cmd = &str[SSID_STR_LEN + 1];
			length = strlen(udp_cmd);

			if ((length == strlen(udp_rom_cmd)) && (strncmp(udp_cmd, udp_rom_cmd, strlen(udp_rom_cmd)) == 0)) {
				udp_service_reply(rom_msg, sizeof(rom_msg) - 1, pcb, addr);
			}
			else
			if ((length == strlen(udp_switch_cmd)) && (strncmp(udp_cmd, udp_switch_cmd, strlen(udp_switch_cmd)) == 0)) {
				rboot_set_current_rom(1);
				udp_service_reply(switch_msg, sizeof(switch_msg) - 1, pcb, addr);

				// reboot
				reboot();
			}
			else
			// set rtc, rtcset=yymmddwwHHMMSS
			if ((length == 21) && (strncmp(udp_cmd, udp_rtcset_cmd, strlen(udp_rtcset_cmd)) == 0)) {
				ok_flag = false;
				// validate date/time digits
				i = 7;
				while ((udp_cmd[i] >= 0x30) && (udp_cmd[i] <= 0x39) && (udp_cmd[i] != '\x0')) {
					i++;
				}

				if (i == 21) {
					// extract date/time
					// day of week
					//   - ds3231, ds1307, mcp7940 = 1-7
					//   - pcf85363, pcf8523 = 0-6
					// php, javascript
					//   ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
					ok_flag = rtcset_ds3231(&udp_cmd[7]);
				}

				if (ok_flag) {
					udp_service_reply(ok_msg, sizeof(ok_msg) - 1, pcb, addr);
				}
				else {
					udp_service_reply(err_msg, sizeof(err_msg) - 1, pcb, addr);
				}
			}
		}

    pbuf_free(p);
  }
}

char *hex2str(uint8 hex, char *out) {
	if (hex < 0x10) {
		__sprintf(out, "0%x", hex);
	} else {
		__sprintf(out, "%x", hex);
	}

	return out;
}

void ICACHE_FLASH_ATTR udp_service_init(void) {
	uint8 mac[8], i;
	char tmp_str[32];

	// get mac address
	wifi_get_macaddr(STATION_IF, &mac[0]);
	for (i=0; i<6; i++) {
		hex2str(mac[i], &tmp_str[i*3]);
	}
	// generate ssid
	__sprintf(SSID, "%s%s%s", &tmp_str[9], &tmp_str[12], &tmp_str[15]);

	lwip_init();
	ptel_pcb = udp_new();
	udp_bind(ptel_pcb, IP_ADDR_ANY, UDP_SERVICE_PORT);
	udp_recv(ptel_pcb, udp_service_recv, NULL);
	//pbuf_free(ptel_pcb);
}
