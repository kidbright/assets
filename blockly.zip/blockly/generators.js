'use strict';

goog.require('Blockly.KidBright');

// =============================================================================
// basic
// =============================================================================
goog.provide('Blockly.KidBright.basic');

Blockly.KidBright['basic_led16x8'] = function(block) {
	var buf = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00];
	for (var x = 0; x < 16; x++) {
		var byte = 0;
		for (var y = 0; y < 8; y++) {
			var val = block.getFieldValue('POS_X' + x + '_Y' + y);
			if (val == 'TRUE') {
				byte |= (0x01 << y);
			};
		}
		buf[x] = byte;
	}

	/*	// swap buffer for adafruit 8x16
		// 0 = 0, 1 = 8, 2 = 1, 3 = 9, 4 = 2, 5 = 10, 6 = 3, 7 = 11
		// 8 = 4, 9 = 12, 10 = 5, 11 = 13, 12 = 6, 13 = 14, 14 = 7, 15 = 15
		var tmp_buf = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00];
		for (var i = 0; i < 16; i++) {
			if ((i % 2) == 0) {
				tmp_buf[i] = buf[parseInt(i / 2)];
			} else {
				tmp_buf[i] = buf[parseInt(i / 2) + 8];
			}
		}
		var str = '';
		for (var i = 0; i < 16; i++) {
			str += '\\x' + tmp_buf[i].toString(16);;
		}*/

	var str = '';
	for (var i = 0; i < 16; i++) {
		str += '\\x' + buf[i].toString(16);;
	}

	return 'i2c_ht16k33_show("' + str + '");\n';
};

Blockly.KidBright['_i2c_ht16k33_scroll'] = function(arg, scroll_flag) {
	var code = '';

	// check to split argument
	var arg_lst = arg.split('`');
	if (arg_lst.length == 2) {
		if (arg_lst[0] == 'fixed_2digits') {
			// fixed 2digits
			code = 'i2c_ht16k33_scroll_number(' + arg_lst[1] + ', ' + scroll_flag + ', true);\n';
		}
		else {
			// string
			code = 'i2c_ht16k33_scroll(' + arg_lst[1] + ', ' + scroll_flag + ');\n';
		}
	}
	else {
		// default is numeric type
		code = 'i2c_ht16k33_scroll_number(' + arg + ', ' + scroll_flag + ', false);\n';
	}

	return code;
}

Blockly.KidBright['basic_led16x8_clr'] = function(block) {
	var ret = 'i2c_ht16k33_show("\\x0\\x0\\x0\\x0\\x0\\x0\\x0\\x0\\x0\\x0\\x0\\x0\\x0\\x0\\x0\\x0");\n';

	return ret;
};

Blockly.KidBright['basic_led16x8_2chars'] = function(block) {
	var argument0 = Blockly.KidBright.valueToCode(block, 'VALUE', Blockly.KidBright.ORDER_ASSIGNMENT) || '0';

	return Blockly.KidBright['_i2c_ht16k33_scroll'](argument0, false);
};

Blockly.KidBright['basic_led16x8_scroll'] = function(block) {
	var argument0 = Blockly.KidBright.valueToCode(block, 'VALUE', Blockly.KidBright.ORDER_ASSIGNMENT) || '0';

	return Blockly.KidBright['_i2c_ht16k33_scroll'](argument0, true);
};

Blockly.KidBright['basic_led16x8_scroll_when_ready'] = function(block) {
	var argument0 = Blockly.KidBright.valueToCode(block, 'VALUE', Blockly.KidBright.ORDER_ASSIGNMENT) || '0';

	return 'if (i2c_ht16k33_idle()) { ' + String(Blockly.KidBright['_i2c_ht16k33_scroll'](argument0, true)).trim() + ' }\n';
};

Blockly.KidBright['basic_delay'] = function(block) {
	return 'vTaskDelay(' + parseInt(1000 * parseFloat(block.getFieldValue('VALUE'))) + ' / portTICK_RATE_MS);\n';
};

Blockly.KidBright['basic_forever'] = function(block) {
	return 'while(1) {\n' + Blockly.KidBright.statementToCode(block, 'HANDLER') + '}\n';
};

Blockly.KidBright['basic_string'] = function(block) {
	return [
		'string' + '`"' + block.getFieldValue('VALUE') + '"',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

// =============================================================================
// math
// =============================================================================
goog.provide('Blockly.KidBright.math');

Blockly.KidBright['math_number'] = function(block) {
	return [
		block.getFieldValue('VALUE'),
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['math_arithmetic'] = function(block) {
	var OPERATORS = {
		ADD: [' + ', Blockly.KidBright.ORDER_ADDITIVE],
		MINUS: [' - ', Blockly.KidBright.ORDER_ADDITIVE],
		MULTIPLY: [' * ', Blockly.KidBright.ORDER_MULTIPLICATIVE],
		DIVIDE: [' / ', Blockly.KidBright.ORDER_MULTIPLICATIVE],
//		POWER: [' ^ ', Blockly.KidBright.ORDER_EXPONENTIATION],
		MODULO: [' % ', Blockly.KidBright.ORDER_MODULUS]
	};
	var tuple = OPERATORS[block.getFieldValue('OP')];
	var operator = tuple[0];
	var order = tuple[1];
	var argument0 = Blockly.KidBright.valueToCode(block, 'A', order) || '0';
	var argument1 = Blockly.KidBright.valueToCode(block, 'B', order) || '0';

	// modulo allow only integer
	if (block.getFieldValue('OP') == 'MODULO') {
		argument0 = '(int)(' + argument0 + ')';
		argument1 = '(int)(' + argument1 + ')';
	}

	return [
		argument0 + operator + argument1,
		order
	];
};

Blockly.KidBright['math_variables_set'] = function(block) {
	var argument0 = Blockly.KidBright.valueToCode(block, 'VALUE', Blockly.KidBright.ORDER_ASSIGNMENT) || '0';
	var varName = Blockly.KidBright.variableDB_.getName(block.getFieldValue('VAR'), Blockly.Variables.NAME_TYPE);

	return varName + ' = ' + argument0 + ';\n';
};

Blockly.KidBright['math_variables_get'] = function(block) {
	var code = Blockly.KidBright.variableDB_.getName(block.getFieldValue('VAR'), Blockly.Variables.NAME_TYPE);

	return [
		code,
		Blockly.KidBright.ORDER_ATOMIC
	];
};

// =============================================================================
// logic
// =============================================================================
goog.provide('Blockly.KidBright.logic');

Blockly.KidBright['controls_if'] = function(block) {
	// If/elseif/else condition.
	var n = 0;
	var argument = Blockly.KidBright.valueToCode(block, 'IF' + n, Blockly.KidBright.ORDER_NONE) || '0';
	var branch = Blockly.KidBright.statementToCode(block, 'DO' + n);
	var code = 'if (' + argument + ') {\n' + branch + '}';

	for (n = 1; n <= block.elseifCount_; n++) {
		argument = Blockly.KidBright.valueToCode(block, 'IF' + n, Blockly.KidBright.ORDER_NONE) || '0';
		branch = Blockly.KidBright.statementToCode(block, 'DO' + n);
		code += ' else if (' + argument + ') {\n' + branch + '}';
	}

	if (block.elseCount_) {
		branch = Blockly.KidBright.statementToCode(block, 'ELSE');
		code += ' else {\n' + branch + '}';
	}

	return code + '\n';
};

Blockly.KidBright['logic_compare'] = function(block) {
	// Comparison operator.
	var OPERATORS = {
		'EQ': '==',
		'NEQ': '!=',
		'LT': '<',
		'LTE': '<=',
		'GT': '>',
		'GTE': '>='
	};

	var operator = OPERATORS[block.getFieldValue('OP')];
	var order = (operator == '==' || operator == '!=') ?
		Blockly.KidBright.ORDER_EQUALITY : Blockly.KidBright.ORDER_RELATIONAL;
	var argument0 = Blockly.KidBright.valueToCode(block, 'A', order) || '0';
	var argument1 = Blockly.KidBright.valueToCode(block, 'B', order) || '0';

	var code = '';
	var arg0_lst = argument0.split('`');
	var arg1_lst = argument1.split('`');
	// check to split argument
	if (arg0_lst.length == 2) {
		if (arg0_lst[0] == 'fixed_2digits') {
			// fixed 2digits
			if (arg1_lst.length == 2) {
				code = arg0_lst[1] + ' ' + operator + ' ' + arg1_lst[1];
			}
			else {
				code = arg0_lst[1] + ' ' + operator + ' ' + argument1;
			}
		}
		else {
			// string
			code = 'strcmp(' + arg0_lst[1] + ', ' + arg1_lst[1] + ') ' + OPERATORS[block.getFieldValue('OP')] + ' 0';
		}
	}
	else {
		// default is numeric
		code = argument0 + ' ' + operator + ' ' + argument1;
	}

	return [code, order];
};

Blockly.KidBright['logic_operation'] = function(block) {
  // Operations 'and', 'or'.
  var operator = (block.getFieldValue('OP') == 'AND') ? '&&' : '||';
  var order = (operator == '&&') ? Blockly.KidBright.ORDER_LOGICAL_AND :
      Blockly.KidBright.ORDER_LOGICAL_OR;
  var argument0 = Blockly.KidBright.valueToCode(block, 'A', order);
  var argument1 = Blockly.KidBright.valueToCode(block, 'B', order);
  if (!argument0 && !argument1) {
    // If there are no arguments, then the return value is false.
    argument0 = 'false';
    argument1 = 'false';
  } else {
    // Single missing arguments have no effect on the return value.
    var defaultArgument = (operator == '&&') ? 'true' : 'false';
    if (!argument0) {
      argument0 = defaultArgument;
    }
    if (!argument1) {
      argument1 = defaultArgument;
    }
  }
  var code = '(' + argument0 + ') ' + operator + ' (' + argument1 + ')';
  return [code, order];
};

Blockly.KidBright['logic_negate'] = function(block) {
  // Negation.
  var order = Blockly.KidBright.ORDER_LOGICAL_NOT;
  var argument0 = Blockly.KidBright.valueToCode(block, 'BOOL', order) ||
      'true';
  var code = '!' + argument0;
  return [code, order];
};

Blockly.KidBright['logic_boolean'] = function(block) {
  // Boolean values true and false.
  var code = (block.getFieldValue('BOOL') == 'TRUE') ? 'true' : 'false';
  return [code, Blockly.KidBright.ORDER_ATOMIC];
};

Blockly.KidBright['logic_led16x8_scroll_ready'] = function(block) {
	//var code = (block.getFieldValue('BOOL') == 'TRUE') ? 'true' : 'false';
	return ['i2c_ht16k33_idle()', Blockly.KidBright.ORDER_ATOMIC];
}

Blockly.KidBright['logic_sw1_pressed'] = function(block) {
	//var code = (block.getFieldValue('BOOL') == 'TRUE') ? 'true' : 'false';
	return ['is_sw1_pressed()', Blockly.KidBright.ORDER_ATOMIC];
}

Blockly.KidBright['logic_sw1_released'] = function(block) {
	//var code = (block.getFieldValue('BOOL') == 'TRUE') ? 'true' : 'false';
	return ['is_sw1_released()', Blockly.KidBright.ORDER_ATOMIC];
}

Blockly.KidBright['logic_sw2_pressed'] = function(block) {
	//var code = (block.getFieldValue('BOOL') == 'TRUE') ? 'true' : 'false';
	return ['is_sw2_pressed()', Blockly.KidBright.ORDER_ATOMIC];
}

Blockly.KidBright['logic_sw2_released'] = function(block) {
	//var code = (block.getFieldValue('BOOL') == 'TRUE') ? 'true' : 'false';
	return ['is_sw2_released()', Blockly.KidBright.ORDER_ATOMIC];
}

// =============================================================================
// loop
// =============================================================================
Blockly.KidBright['controls_whileUntil'] = function(block) {
  // Do while/until loop.
  var until = block.getFieldValue('MODE') == 'UNTIL';
  var argument0 = Blockly.KidBright.valueToCode(block, 'BOOL',
      until ? Blockly.KidBright.ORDER_LOGICAL_NOT :
      Blockly.KidBright.ORDER_NONE) || 'false';
  var branch = Blockly.KidBright.statementToCode(block, 'DO');

//testbug
//console.log('controls_whileUntil');

  branch = Blockly.KidBright.addLoopTrap(branch, block.id);

//testbug
//console.log('addLoopTrap');

  if (until) {
    argument0 = '!' + argument0;
  }
  return 'while (' + argument0 + ') {\n' + branch + '}\n';
};

Blockly.KidBright['loop_break'] = function(block) {
	var ret = 'break;\n';
	return ret;
};

Blockly.KidBright['loop_continue'] = function(block) {
	var ret = 'continue;\n';
	return ret;
};

// =============================================================================
// wait
// =============================================================================
Blockly.KidBright['wait_led_matrix_ready'] = function(block) {
	var ret = 'wait_led_matrix_ready();\n';
	return ret;
};

Blockly.KidBright['wait_sw1_pressed'] = function(block) {
	var ret = 'wait_sw1_pressed();\n';
	return ret;
};

Blockly.KidBright['wait_sw1_released'] = function(block) {
	var ret = 'wait_sw1_released();\n';
	return ret;
};

Blockly.KidBright['wait_sw2_pressed'] = function(block) {
	var ret = 'wait_sw2_pressed();\n';
	return ret;
};

Blockly.KidBright['wait_sw2_released'] = function(block) {
	var ret = 'wait_sw2_released();\n';
	return ret;
};

// =============================================================================
// music
// =============================================================================
goog.provide('Blockly.KidBright.music');

Blockly.KidBright['music_note'] = function(block) {
	var ret =
		'sound_note(' + block.getFieldValue('NOTE') + ');\n' +
		'sound_rest(' + block.getFieldValue('DURATION') + ');\n' +
		'sound_off();\n';

	return ret;
};

Blockly.KidBright['music_rest'] = function(block) {
	return 'sound_rest(' + block.getFieldValue('DURATION') + ');\n';
};

Blockly.KidBright['music_set_tempo'] = function(block) {
	return 'sound_set_bpm(' + block.getFieldValue('VALUE') + ');\n';
};

// =============================================================================
// sensor
// =============================================================================
goog.provide('Blockly.KidBright.sensor');

Blockly.KidBright['sensor_lm73'] = function(block) {
	return [
		'fixed_2digits' + '`' + 'i2c_lm73_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['sensor_ldr'] = function(block) {
	return [
		'ldr_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['sensor_switch1'] = function(block) {
	return [
		'switch1_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['sensor_switch2'] = function(block) {
	return [
		'switch2_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

// =============================================================================
// rtc
// =============================================================================
goog.provide('Blockly.KidBright.rtc');

Blockly.KidBright['rtc_get'] = function(block) {
	return [
		'string' + '`' + 'i2c_ds3231_get_datetime()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};
Blockly.KidBright['rtc_get_date'] = function(block) {
	return [
		'string' + '`' + 'i2c_ds3231_get_date()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};
Blockly.KidBright['rtc_get_time'] = function(block) {
	return [
		'string' + '`' + 'i2c_ds3231_get_time()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};
Blockly.KidBright['rtc_get_day'] = function(block) {
	return [
		'i2c_ds3231_get(0)',
		Blockly.KidBright.ORDER_ATOMIC
	];
};
Blockly.KidBright['rtc_get_month'] = function(block) {
	return [
		'i2c_ds3231_get(1)',
		Blockly.KidBright.ORDER_ATOMIC
	];
};
Blockly.KidBright['rtc_get_year'] = function(block) {
	return [
		'i2c_ds3231_get(2)',
		Blockly.KidBright.ORDER_ATOMIC
	];
};
Blockly.KidBright['rtc_get_hour'] = function(block) {
	return [
		'i2c_ds3231_get(3)',
		Blockly.KidBright.ORDER_ATOMIC
	];
};
Blockly.KidBright['rtc_get_minute'] = function(block) {
	return [
		'i2c_ds3231_get(4)',
		Blockly.KidBright.ORDER_ATOMIC
	];
};
Blockly.KidBright['rtc_get_second'] = function(block) {
	return [
		'i2c_ds3231_get(5)',
		Blockly.KidBright.ORDER_ATOMIC
	];
};
Blockly.KidBright['rtc_cal'] = function(block) {
	var ret = 'i2c_ds3231_cal(' + block.getFieldValue('VALUE') + ');\n';
	return ret;
};
Blockly.KidBright['rtc_cal_coarse'] = function(block) {
	var ret = 'i2c_ds3231_cal_coarse(' + block.getFieldValue('VALUE') + ');\n';
	return ret;
};
// =============================================================================
// comm
// =============================================================================
goog.provide('Blockly.KidBright.comm');

Blockly.KidBright['_os_printf'] = function(arg, newline_flag) {
	var newline_fn = '';
	if (newline_flag) {
		newline_fn = 'ln';
	}

	var code = '';
	// check to split argument
	var arg_lst = arg.split('`');
	if (arg_lst.length == 2) {
		if (arg_lst[0] == 'fixed_2digits') {
			// fixed 2digits
			code = 'uart_print' + newline_fn + '_number(' + arg_lst[1] + ', true);\n';
		}
		else {
			// string
			code = 'uart_print' + newline_fn + '(' + arg_lst[1] + ');\n';
		}
	}
	else {
		// default is numeric type
		code = 'uart_print' + newline_fn + '_number(' + arg + ', false);\n';
	}

	return code;
}

Blockly.KidBright['comm_uart_write'] = function(block) {
	var argument0 = Blockly.KidBright.valueToCode(block, 'VALUE', Blockly.KidBright.ORDER_ASSIGNMENT) || '0';

	return Blockly.KidBright['_os_printf'](argument0, false);
};

Blockly.KidBright['comm_uart_writeln'] = function(block) {
	var argument0 = Blockly.KidBright.valueToCode(block, 'VALUE', Blockly.KidBright.ORDER_ASSIGNMENT) || '0';

	return Blockly.KidBright['_os_printf'](argument0, true);
};

// =============================================================================
// advance
// =============================================================================
goog.provide('Blockly.KidBright.advance');

Blockly.KidBright['advance_task'] = function(block) {
	// generate unique function name
	Blockly.KidBright.taskNumber++;
	var funcName = 'vTask' + Blockly.KidBright.taskNumber;

	var branch = Blockly.KidBright.statementToCode(block, 'STACK');
	if (Blockly.KidBright.STATEMENT_PREFIX) {
		branch = Blockly.KidBright.prefixLines(
			Blockly.KidBright.STATEMENT_PREFIX.replace(/%1/g,
				'\'' + block.id + '\''), Blockly.KidBright.INDENT) + branch;
	}
	if (Blockly.KidBright.INFINITE_LOOP_TRAP) {
		branch = Blockly.KidBright.INFINITE_LOOP_TRAP.replace(/%1/g,
			'\'' + block.id + '\'') + branch;
	}
	var code = 'LOCAL void ' + funcName + '(void *pvParameters) {\n' +
		branch +
		'  // kill itself\n' +
		'  vTaskDelete(NULL);\n' +
		'}';
	code = Blockly.KidBright.scrub_(block, code);
	// Add % so as not to collide with helper functions in definitions list.
	Blockly.KidBright.definitions_['%' + funcName] = code;
	return null;
};

Blockly.KidBright['advance_gpio0_write'] = function(block) {
	var ret = 'gpio0_write(' + block.getFieldValue('STATUS') + ');\n';
	return ret;
};

Blockly.KidBright['advance_gpio0_toggle'] = function(block) {
	var ret = 'gpio0_toggle();\n';
	return ret;
};

Blockly.KidBright['advance_gpio0_read'] = function(block) {
	return [
		'gpio0_read()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['advance_current_drain_write'] = function(block) {
	var ret = 'current_drain_write(' + block.getFieldValue('STATUS') + ');\n';
	return ret;
};

// =============================================================================
// sensor hub
// =============================================================================
Blockly.KidBright['sensor_hub_1'] = function(block) {
	return [
		'sensor_hub_d1_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['sensor_hub_2'] = function(block) {
	return [
		'sensor_hub_d2_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['sensor_hub_3'] = function(block) {
	return [
		'sensor_hub_d3_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['sensor_hub_4'] = function(block) {
	return [
		'sensor_hub_d4_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['sensor_hub_5'] = function(block) {
	return [
		'sensor_hub_w1_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['sensor_hub_6'] = function(block) {
	return [
		'sensor_hub_w2_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['sensor_hub_usb1_write'] = function(block) {
	var ret = 'sensor_hub_u1_write(' + block.getFieldValue('STATUS') + ');\n';
	return ret;
};

Blockly.KidBright['sensor_hub_usb1_toggle'] = function(block) {
	var ret = 'sensor_hub_u1_toggle();\n';
	return ret;
};

Blockly.KidBright['sensor_hub_usb1_read'] = function(block) {
	return [
		'sensor_hub_u1_read()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['sensor_hub_usb2_write'] = function(block) {
	var ret = 'sensor_hub_u2_write(' + block.getFieldValue('STATUS') + ');\n';
	return ret;
};

Blockly.KidBright['sensor_hub_usb2_toggle'] = function(block) {
	var ret = 'sensor_hub_u2_toggle();\n';
	return ret;
};

Blockly.KidBright['sensor_hub_usb2_read'] = function(block) {
	return [
		'sensor_hub_u2_read()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

// =============================================================================
// swled
// =============================================================================
Blockly.KidBright['swled_led1_write'] = function(block) {
	var ret = 'swled_led1_write(' + block.getFieldValue('STATUS') + ');\n';
	return ret;
};

Blockly.KidBright['swled_led1_toggle'] = function(block) {
	var ret = 'swled_led1_toggle();\n';
	return ret;
};

Blockly.KidBright['swled_led2_write'] = function(block) {
	var ret = 'swled_led2_write(' + block.getFieldValue('STATUS') + ');\n';
	return ret;
};

Blockly.KidBright['swled_led2_toggle'] = function(block) {
	var ret = 'swled_led2_toggle();\n';
	return ret;
};

Blockly.KidBright['swled_led3_write'] = function(block) {
	var ret = 'swled_led3_write(' + block.getFieldValue('STATUS') + ');\n';
	return ret;
};

Blockly.KidBright['swled_led3_toggle'] = function(block) {
	var ret = 'swled_led3_toggle();\n';
	return ret;
};

Blockly.KidBright['swled_led4_write'] = function(block) {
	var ret = 'swled_led4_write(' + block.getFieldValue('STATUS') + ');\n';
	return ret;
};

Blockly.KidBright['swled_led4_toggle'] = function(block) {
	var ret = 'swled_led4_toggle();\n';
	return ret;
};

Blockly.KidBright['swled_sw1'] = function(block) {
	return [
		'swled_sw1_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['swled_sw2'] = function(block) {
	return [
		'swled_sw2_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['swled_sw3'] = function(block) {
	return [
		'swled_sw3_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['swled_sw4'] = function(block) {
	return [
		'swled_sw4_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

// =============================================================================
// relay
// =============================================================================
Blockly.KidBright['relay1_write'] = function(block) {
	//var ret = 'relay1_write(' + block.getFieldValue('STATUS') + ');\n';
	var ret = 'relay_write(0, ' + block.getFieldValue('STATUS') + ');\n';
	return ret;
};

Blockly.KidBright['relay1_toggle'] = function(block) {
	//var ret = 'relay1_toggle();\n';
	var ret = 'relay_toggle(0);\n';
	return ret;
};

Blockly.KidBright['relay1'] = function(block) {
	return [
		'relay1_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['relay2_write'] = function(block) {
	//var ret = 'relay2_write(' + block.getFieldValue('STATUS') + ');\n';
	var ret = 'relay_write(1, ' + block.getFieldValue('STATUS') + ');\n';
	return ret;
};

Blockly.KidBright['relay2_toggle'] = function(block) {
	//var ret = 'relay2_toggle();\n';
	var ret = 'relay_toggle(1);\n';
	return ret;
};

Blockly.KidBright['relay2'] = function(block) {
	return [
		'relay2_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['relay3_write'] = function(block) {
	//var ret = 'relay3_write(' + block.getFieldValue('STATUS') + ');\n';
	var ret = 'relay_write(2, ' + block.getFieldValue('STATUS') + ');\n';
	return ret;
};

Blockly.KidBright['relay3_toggle'] = function(block) {
	//var ret = 'relay3_toggle();\n';
	var ret = 'relay_toggle(2);\n';
	return ret;
};

Blockly.KidBright['relay3'] = function(block) {
	return [
		'relay3_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};

Blockly.KidBright['relay4_write'] = function(block) {
	//var ret = 'relay4_write(' + block.getFieldValue('STATUS') + ');\n';
	var ret = 'relay_write(3, ' + block.getFieldValue('STATUS') + ');\n';
	return ret;
};

Blockly.KidBright['relay4_toggle'] = function(block) {
	//var ret = 'relay4_toggle();\n';
	var ret = 'relay_toggle(3);\n';
	return ret;
};

Blockly.KidBright['relay4'] = function(block) {
	return [
		'relay4_get()',
		Blockly.KidBright.ORDER_ATOMIC
	];
};
